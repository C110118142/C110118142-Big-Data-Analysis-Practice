from django.apps import AppConfig


class AppUserKeywordAssociationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_user_keyword_llm_report'
