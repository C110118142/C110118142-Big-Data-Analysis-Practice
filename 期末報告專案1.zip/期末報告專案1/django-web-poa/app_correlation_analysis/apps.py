from django.apps import AppConfig


class AppTopPersonConfig(AppConfig):
    name = 'app_correlation_analysis'
