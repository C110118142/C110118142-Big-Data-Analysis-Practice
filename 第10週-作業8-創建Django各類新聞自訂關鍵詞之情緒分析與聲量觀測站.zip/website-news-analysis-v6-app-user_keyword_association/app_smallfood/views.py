from django.http import JsonResponse
from django.shortcuts import render
import pandas as pd

def load_data_smallfood():
    # Read data from csv file
    df_data = pd.read_csv('app_smallfood/dataset/smallfood_data.csv',sep=',')
    global response
    response = dict(list(df_data.values))
    del df_data

# load data
load_data_smallfood()

#print(response)

def home(request):
    return render(request,'app_smallfood/home.html', response)

print('app_smallfood was loaded!')
