from django.apps import AppConfig


class AppTaipeiMayorConfig(AppConfig):
    name = 'app_taipei_mayor'
