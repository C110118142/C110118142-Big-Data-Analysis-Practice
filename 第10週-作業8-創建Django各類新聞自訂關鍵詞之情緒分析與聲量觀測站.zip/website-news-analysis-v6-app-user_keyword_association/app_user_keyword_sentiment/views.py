from django.http import JsonResponse
from django.shortcuts import render
import pandas as pd
from datetime import datetime, timedelta
from django.views.decorators.csrf import csrf_exempt
import requests

# 不再從其他 app 匯入 filter_dataFrame
# from app_user_keyword.views import filter_dataFrame
import app_user_keyword.views as userkeyword_views

def load_df_data_v1():
    global df
    df = pd.read_csv('app_user_keyword_sentiment/dataset/food_dataset_preprocessed_for_django.csv', sep='|')

def load_df_data():
    global df
    df = userkeyword_views.df

# 預設直接載入固定CSV
load_df_data_v1()

def home(request):
    return render(request, 'app_user_keyword_sentiment/home.html')

@csrf_exempt
def api_get_userkey_sentiment_from_remote_api_through_backend(request):
    userkey = request.POST['userkey']
    cate = request.POST['cate']
    cond = request.POST['cond']
    weeks = int(request.POST['weeks'])

    try:
        url_api_get_sentiment = "http://163.18.23.20:8000/userkeyword_senti/api_get_userkey_sentiment/"
        sentiment_data = {
            'userkey': userkey,
            'cate': cate,
            'cond': cond,
            'weeks': weeks
        }
        sentiment_response = requests.post(url_api_get_sentiment, data=sentiment_data, timeout=5)
        if sentiment_response.status_code == 200:
            print("由後端呼叫他處API，取得情感分析數據成功!")
            response = sentiment_response.json()
            return JsonResponse(response)
        else:
            print(f"回傳有錯誤，進行本地處理資料")
            print(f"Sentiment API error: {sentiment_response.status_code}")
            return JsonResponse({'error': 'Failed to get sentiment analysis.'})
    except Exception as e:
        print(f"An unexpected error occurred while processing sentiment data: {e}")
        print(f"呼叫異常失敗，進行本地處理資料")
        return JsonResponse({'error': 'An internal error occurred while processing sentiment data.'}, status=500)

@csrf_exempt
def api_get_userkey_sentiment(request):
    userkey = request.POST['userkey']
    cate = request.POST['cate']
    cond = request.POST['cond']
    weeks = int(request.POST['weeks'])

    query_keywords = userkey.split()
    df_query = filter_dataFrame_local(query_keywords, cond, cate, weeks)

    if len(df_query) == 0:
        return JsonResponse({'error': 'No results found for the given keywords.'})


    sentiCount, sentiPercnt = get_article_sentiment(df_query)

    freq_type = 'D' if weeks <= 4 else '5D'
    line_data_pos = get_daily_basis_sentiment_count(df_query, 'pos', freq_type)
    line_data_neg = get_daily_basis_sentiment_count(df_query, 'neg', freq_type)


    response = {
        'sentiCount': sentiCount,
        'data_pos': line_data_pos,
        'data_neg': line_data_neg,
    }
    return JsonResponse(response)

# ✅ 自定義 filter function，改為使用本地的 global df
def filter_dataFrame_local(keywords, cond, cate, weeks):
    global df
    df_copy = df.copy()

    if cate != '全部':
        df_copy = df_copy[df_copy['category'] == cate]

    if cond == 'and':
        condition = df_copy['content'].apply(lambda text: all((kw in str(text)) for kw in keywords))
    else:  # 'or'
        condition = df_copy['content'].apply(lambda text: any((kw in str(text)) for kw in keywords))

    df_copy = df_copy[condition]

    latest_date = pd.to_datetime(df_copy['date'], errors='coerce').max()
    cutoff_date = latest_date - timedelta(weeks=weeks)
    df_copy['date'] = pd.to_datetime(df_copy['date'], errors='coerce')
    df_copy = df_copy[df_copy['date'] >= cutoff_date]

    return df_copy

def get_article_sentiment(df_query):
    sentiCount = {'Positive': 0, 'Negative': 0, 'Neutral': 0}
    sentiPercnt = {'Positive': 0, 'Negative': 0, 'Neutral': 0}
    valid_article_count = 0

    for senti in df_query.sentiment:
        try:
            score = float(senti)
            valid_article_count += 1
            if score >= 0.6:
                sentiCount['Positive'] += 1
            elif score <= 0.4:
                sentiCount['Negative'] += 1
            else:
                sentiCount['Neutral'] += 1
        except ValueError:
            continue

    for polar in sentiCount:
        try:
            sentiPercnt[polar] = int(sentiCount[polar] / valid_article_count * 100)
        except ZeroDivisionError:
            sentiPercnt[polar] = 0

    return sentiCount, sentiPercnt

def is_float(value):
    try:
        float(value)
        return True
    except (ValueError, TypeError):
        return False

def get_daily_basis_sentiment_count(df_query, sentiment_type='pos', freq_type='D'):
    if sentiment_type == 'pos':
        lambda_function = lambda senti: 1 if senti >= 0.6 else 0
    elif sentiment_type == 'neg':
        lambda_function = lambda senti: 1 if senti <= 0.4 else 0
    elif sentiment_type == 'neutral':
        lambda_function = lambda senti: 1 if 0.4 < senti < 0.6 else 0
    else:
        return []

    try:
        freq_df = pd.DataFrame({
            'date_index': pd.to_datetime(df_query.date, errors='coerce'),
            'frequency': [
                lambda_function(float(senti)) if is_float(senti) else 0
                for senti in df_query.sentiment
            ]
        })
    except Exception as e:
        print(f"[錯誤] 時間格式轉換失敗: {e}")
        return []

    freq_df.dropna(subset=['date_index'], inplace=True)

    if freq_df.empty:
        return []

    freq_df_group = freq_df.groupby(pd.Grouper(key='date_index', freq=freq_type)).sum().reset_index()

    xy_line_data = [{'x': date.strftime('%Y-%m-%d'), 'y': freq}
                    for date, freq in zip(freq_df_group.date_index, freq_df_group.frequency)]

    return xy_line_data

print("app_userkey_sentiment was loaded!")
