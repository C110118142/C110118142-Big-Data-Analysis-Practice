from django.apps import AppConfig


class AppUserKeywordSentimentConfig(AppConfig):
    name = 'app_user_keyword_sentiment'
