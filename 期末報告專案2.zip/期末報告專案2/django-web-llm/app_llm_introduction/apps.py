from django.apps import AppConfig


class AppPoaIntroductionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_llm_introduction'
